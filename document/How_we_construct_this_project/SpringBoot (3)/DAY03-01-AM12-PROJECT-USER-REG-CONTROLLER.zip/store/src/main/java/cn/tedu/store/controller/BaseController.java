package cn.tedu.store.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;

import cn.tedu.store.service.ex.InsertException;
import cn.tedu.store.service.ex.ServiceException;
import cn.tedu.store.service.ex.UsernameDuplicateException;
import cn.tedu.store.util.ResponseResult;

/**
 * 控制器类的基类
 */
public class BaseController {
	
	/**
	 * 响应结果的状态：成功
	 */
	public static final Integer SUCCESS = 100;

	/**
	 * 统一处理异常
	 * @param e
	 * @return
	 */
	@ExceptionHandler(ServiceException.class)
	public ResponseResult<Void> handleException(Throwable e) {
		ResponseResult<Void> rr
			= new ResponseResult<Void>();
		rr.setMessage(e.getMessage());
		
		if (e instanceof UsernameDuplicateException) {
			rr.setState(2);
		} else if (e instanceof InsertException) {
			rr.setState(3);
		}
		
		return rr;
	}
	
}
