import org.springframework.web.multipart.commons.CommonsMultipartResolver;

public class TestCase {
	
	CommonsMultipartResolver cmr;

}
