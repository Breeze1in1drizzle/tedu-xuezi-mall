package cn.tedu.spring;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FileUploadController {

	@RequestMapping("/upload.do")
	public String handleUpload(
		@RequestParam("file") MultipartFile file) 
			throws IllegalStateException, IOException {
		File dest = new File("d:/12345.png");
		file.transferTo(dest);
		return null;
	}
	
}




