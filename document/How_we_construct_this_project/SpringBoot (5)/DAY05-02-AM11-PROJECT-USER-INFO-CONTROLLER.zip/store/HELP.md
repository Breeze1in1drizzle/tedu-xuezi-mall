# Getting Started

### Guides
The following guides illustrates how to use certain features concretely:

* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Quick Start](https://github.com/mybatis/spring-boot-starter/wiki/Quick-Start)

