import org.springframework.web.multipart.commons.CommonsMultipartResolver;

public class TestCase {
	
	CommonsMultipartResolver cmr;

	public static void main(String[] args) {
		System.out.println(5 * 1024 * 1024);
		
		long start = System.currentTimeMillis();
		for (int i = 0; i < 10; i++) {
			System.out.println(System.nanoTime());
		}
		long end = System.currentTimeMillis();
		System.out.println(end - start);
	}
	
}
